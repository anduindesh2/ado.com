
let utilisateurActuel = prompt("Quel est ton pseudo ?") || "Invité";
document.getElementById("currentUser").innerText = utilisateurActuel;

const publications = [];
const messages = [];

function publierPost() {
  const contenu = document.getElementById("newPost").value.trim();
  if (contenu) {
    publications.unshift({ auteur: utilisateurActuel, texte: contenu });
    document.getElementById("newPost").value = '';
    afficherPosts();
  }
}

function afficherPosts() {
  const feed = document.getElementById("feed");
  feed.innerHTML = publications.map(p => `
    <div class="post">
      <strong>@${p.auteur}</strong><br>
      <p>${p.texte}</p>
    </div>
  `).join('');
}

function envoyerMessage() {
  const msg = document.getElementById("message").value.trim();
  if (msg) {
    messages.push({ auteur: utilisateurActuel, texte: msg });
    document.getElementById("message").value = '';
    afficherMessages();
  }
}

function afficherMessages() {
  const chat = document.getElementById("chat");
  chat.innerHTML = messages.map(m => `<p><strong>@${m.auteur}</strong> : ${m.texte}</p>`).join('');
  chat.scrollTop = chat.scrollHeight;
}
